<?php
session_start();

include ("../modelo/mostrar_productos.php");
$obj = new producto();
$resultado = $obj -> product();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="Configuracion/css/bootstrap-theme.min.css">
  <link rel="stylesheet" href="Configuracion/css/fontAwesome.css">
  <link rel="stylesheet" href="Configuracion/css/hero-slider.css">
  <link rel="stylesheet" href="Configuracion/css/owl-carousel.css">
  <link rel="stylesheet" href="Configuracion/css/datepicker.css">
  <link rel="stylesheet" href="Configuracion/css/templatemo-style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400" rel="stylesheet" /> <!-- https://fonts.google.com/ -->
  <link rel="stylesheet" href="Configuracion/css/tooplate-wave-cafe.css">
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<div class="wrap">
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <button id="primary-nav-button" type="button">Menu</button>
                        <a href="inicio"><div class="logo">
                            <img src="Configuracion/images/vet31.png" alt="Venue Logo">
                        </div></a>
                        <nav id="primary-nav" class="dropdown cf">
                            <ul class="dropdown menu">
                                <li class='active'><a href="inicio">Inicio</a></li>
                                <li><a href="admin">Productos</a></li>
                                <li><a class="scrollTo" data-scrollTo="contact" href="#">Bienvenido<?php echo $_SESSION['nombre']; ?></a>
                                <ul class="sub-menu">
                                    <li><a href="carrito">carrito</a></li>
                                    <li><a href="cierre">Cerrar Sesion</a></li>
                                </ul>
                            </ul>
                        </nav><!-- / #primary-nav -->
                    </div>
                </div>
            </div>
        </header>
    </div>

    <div class="container">
    <button class="btn btn-info" data-toggle="modal" data-target="#add_name">Agregar</button>
    <br>
    <br>
    <!----------------------Titulos de la tabla----------------------->
      <table class="table table-dark">
        <thead>
          <tr>
            <th>id</th>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Opcion</th>
          </tr>
        </thead>
        <tbody>
    <!----------------------Titulos de la tabla(nombre de las variables en la base de datos----------------------->
        <?php foreach($resultado as $r){ ?>
          <tr>
            <td><?php echo $r['id'] ?></td>
            <td><?php echo $r['name'] ?>  </td>
            <td><?php echo $r['price'] ?></td>
            <td>
    <!----------------------Botones de la tabla con nombre de las variables en la base de datos----------------------->
                <button class="btn btn-danger" onclick="eliminar('<?php echo $r['id'] ?>','<?php echo $r['name'] ?>','<?php echo $r['price'] ?>')" >Eliminar</button>
                <button class="btn btn-info" data-toggle="modal" data-target="#modal<?php echo $r['id'] ?>">Modificar</button>
            </td>
          </tr>

          <!-- The Modal( ventana para que se vea la parte de modificar) -->
          <div class="modal fade" id="modal<?php echo $r['id'] ?>">
                        <div class="modal-dialog">
                            <div class="modal-content">

                                <!-- Modal Header -->
                                <div class="modal-header">
                                    <h4 class="modal-title">MODIFICAR PEDIDO</h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>

                                <!-- Modal body -->
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label for="name">PRODUCTO A MODIFICAR:</label>
                                        <input type="text" class="form-control" value="<?php echo $r['name'] ?>" id="name<?php echo $r['id'] ?>">
                                        <input type="hidden" name="" id="id_name_<?php echo $r['id'] ?>" value="<?php echo $r['id'] ?>" >
                                    </div>
                                </div>

                                <!-- Modal footer -->
                                <div class="modal-footer">
                                  <button onclick="modificar(
                                  document.getElementById('id_name_<?php echo $r['id'] ?>').value,
                                  document.getElementById('name<?php echo $r['id'] ?>').value)" type="button" class="btn btn-primary" >Modificar</button>
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                                </div>

                            </div>
                        </div>
            </div>

        <?php } ?>
        </tbody>
      </table>
    </div>


<!-- The Modal( ventana para que se vea la parte de agregar) -->
    <div class="modal fade" id="add_name">
        <div class="modal-dialog">
          <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
              <h4 class="modal-title">Agregar Pedido</h4>
              <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
            <div class="form-group">
            <label for="agregar_name">Producto:</label>
            <input placeholder="INGRESAR PRODUCTO" type="text" name="" id="agrega_name" class="form-control" >
            <input placeholder="INGRESAR PRECIO" type="number" name="" id="agrega_price" class="form-control" >
            </div>
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
              <button class="btn btn-primary" onclick="agregar()">Agregar</button>
              <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
            </div>

          </div>
        </div>
      </div>

    </div>



        <script src="Configuracion/js/eliminar.js"></script>
        <script src="Configuracion/js/modificar.js"></script>
        <script src="Configuracion/js/agregar.js"></script>
    </body>
    </html>