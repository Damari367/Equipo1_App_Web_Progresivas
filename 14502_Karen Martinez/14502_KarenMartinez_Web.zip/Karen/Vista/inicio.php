<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Karen</title>

    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="Configuracion/css/bootstrap.min.css">
    <link rel="stylesheet" href="Configuracion/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="Configuracion/css/fontAwesome.css">
    <link rel="stylesheet" href="Configuracion/css/hero-slider.css">
    <link rel="stylesheet" href="Configuracion/css/owl-carousel.css">
    <link rel="stylesheet" href="Configuracion/css/datepicker.css">
    <link rel="stylesheet" href="Configuracion/css/templatemo-style.css">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">

    <link href="https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900" rel="stylesheet">

    <script src="Configuracion/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    <!--
	Venue Template
	http://www.templatemo.com/tm-522-venue
-->
</head>
<style>
.carousel-inner img {
    width: 100%;
    height: 100%;
}

.carousel-inner {
    height: 600px;
}
</style>

<body>
    <!------------------------------seccion 1--------------------------------------------------->
    <div class="wrap">
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <button id="primary-nav-button" type="button">Menu</button>
                        <a href="index.html">
                            <div class="logo">
                                <img src="Configuracion/images/vet31.png" alt="Venue Logo">
                            </div>
                        </a>
                        <nav id="primary-nav" class="dropdown cf">
                            <ul class="dropdown menu">
                                <li class='active'><a href="index.html">Inicio</a></li>
                                <li><a href="admin">Productos</a></li>
                                <li><a class="scrollTo" data-scrollTo="contact"
                                        href="#">Bienvenido<?php echo $_SESSION['nombre']; ?></a>
                                    <ul class="sub-menu">
                                        <li><a href="producto">carrito</a></li>
                                        <li><a href="cierre">Cerrar Sesion</a></li>
                                    </ul>
                            </ul>
                        </nav><!-- / #primary-nav -->
                    </div>
                </div>
            </div>
        </header>
    </div>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <h3>
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            </h3>
        </ol>
    </nav>
    <!------------------------------Fin seccion 1--------------------------------------------------->
    <!------------------------------seccion 2--------------------------------------------------->
    <section class="banner" id="top">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="banner-caption">
                        <div class="line-dec"></div>
                        <h2>Perros</h2>
                        <span>En esta clinica, Tu mascota es primero</span>
                        <div class="blue-button">
                            <a class="scrollTo" data-scrollTo="contacto" href="#">Contactanos</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        </div>
    </section>
    <!------------------------------Fin seccion 2--------------------------------------------------->
    <!------------------------------seccion 4--------------------------------------------------->
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
        </ol>


        <!------------------------------Fin seccion 4--------------------------------------------------->

        <!------------------------------seccion 5--------------------------------------------------->
        <section class="our-services" id="services">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="section-heading">

                            <h2>Servicio que ofrecemos</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="service-item">
                            <div class="icon">

                            </div>
                            <h4>Clinica</h4>
                            <p>Los servicios que se proporcionan en esta area son de recepción, consulta, cirugía,
                                hospitalización, radiología</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="service-item">
                            <div class="icon">

                            </div>
                            <h4>Estetica</h4>
                            <p>Los servicios que se proporcionan en esta area son baño, lavado de oidos, corte de pelo,
                                corte de uñas, se le revisa los sacos anales, se le agrega esencia</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="service-item">
                            <div class="icon">

                            </div>
                            <h4>Adiestramiento</h4>
                            <p>En esta area se le hace un diagnostico a el perro y dependiendo el analisis, es el
                                adiestramiento que se le recomienda </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="down-services">
                            <div class="row">
                                <div class="col-md-5 col-md-offset-1">
                                    <div class="left-content">
                                        <h4>¿Sabes que son los sacos anales?</h4>
                                        <p>Los sacos anales son dos estructuras situadas a ambos lados del ano, debajo
                                            de la cola. Se encuentran también presentes en otros carnívoros como el
                                            hurón. Contienen un líquido aceitoso, espeso y oscuro, de olor muy fuerte y
                                            característico.</p>
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="accordions">
                                        <ul class="accordion">
                                            <li>
                                                <a>¿Que tipo de vacunas se recomienda a los perros cachorros?</a>
                                                <p>vacuna de parvovirus y virus del moquillo. A los 2 meses: vacuna
                                                    denominada Polivalente (parvovirus, virus del moquillo, virus de la
                                                    para influenza, virus de la hepatitis leptospira). A los 3 meses:
                                                    refuerzo de la vacuna Polivalente.</p>
                                            </li>
                                            <li>
                                                <a>¿Sabes que es la leptospira?</a>
                                                <p>es una infección provocada por especies de bacterias del género
                                                    Leptospira y se transmite a través de la orina de animales
                                                    infectados, entre los que se incluyen roedores, ganado, cerdos y
                                                    perros. Los humanos pueden contagiarse por: contacto directo con
                                                    orina u otros fluidos corporales (excepto saliva) de animales
                                                    infectados, contacto con suelo, agua o comida contaminados con orina
                                                    de animales infectados.</p>
                                            </li>
                                            <li>
                                                <a>¿Porque es importante desparacitar a tu perro/gato?</a>
                                                <p>es importante para prevenir enfermedades, trasmitidas en ocasiones
                                                    por garrapatas, pulgas y otros insectos, considerados parásitos.</p>
                                            </li>
                                        </ul> <!-- / accordion -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!------------------------------Fin seccion 5--------------------------------------------------->

        <!------------------------------seccion 6--------------------------------------------------->
        <section id="video-container">
            <div class="video-overlay"></div>
            <div class="video-content">
                <div class="inner">
                    <span>Pastor Aleman</span>
                    <h2>¿Porque elegir un Pastor Aleman como mascota?</h2>
                    <a href="https://www.youtube.com/watch?v=KJNskrsFfLs" target="_blank"><i class="fa fa-play"></i></a>
                </div>
            </div>
            <video autoplay="" loop="" muted>
                <source src="Configuracion/images/Pastor.mp4" type="video/mp4" />
            </video>
        </section>

        <!------------------------------Fin seccion 6--------------------------------------------------->

        <!------------------------------seccion 8--------------------------------------------------->

        <section class="contact" id="contact">
            <div id="map">
                <!-- How to change your own map point
                           1. Go to Google Maps
                           2. Click on your location point
                           3. Click "Share" and choose "Embed map" tab
                           4. Copy only URL and paste it within the src="" field below
                    -->

                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3595.268536245932!2d-100.50091125009195!3d25.695531517528835!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x866299d47633610f%3A0xd4770aee458aeb5f!2sVetDoctor%20Cl%C3%ADnica%20Veterinaria!5e0!3m2!1ses-419!2smx!4v1613587439003!5m2!1ses-419!2smx"
                    width="100%" height="500px" frameborder="0" style="border:0" allowfullscreen></iframe>

            </div>
            <!----
        <div class="container">
            <div class="col-md-10 col-md-offset-1">
                <div class="wrapper">
                  <div class="section-heading">
                      <span>Contact Us</span>
                      <h2>Vivamus nec vehicula felis</h2>
                  </div>

                  <button id="modBtn" class="modal-btn">Talk to us</button>
                </div>
                <div id="modal" class="modal">

                  <div class="modal-content">
                    <div class="close fa fa-close"></div>
                    <div class="row">
                        <div class="col-md-8">
                            <div class="left-content">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="section-heading">
                                            <span>Talk To Us</span>
                                            <h2>Let's have a discussion</h2>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                      <fieldset>
                                        <input name="name" type="text" class="form-control" id="name" placeholder="Your name..." required="">
                                      </fieldset>
                                    </div>
                                     <div class="col-md-6">
                                      <fieldset>
                                        <input name="subject" type="text" class="form-control" id="subject" placeholder="Subject..." required="">
                                      </fieldset>
                                    </div>
                                    <div class="col-md-12">
                                      <fieldset>
                                        <textarea name="message" rows="6" class="form-control" id="message" placeholder="Your message..." required=""></textarea>
                                      </fieldset>
                                    </div>
                                    <div class="col-md-12">
                                      <fieldset>
                                        <button type="submit" id="form-submit" class="btn">Send Message</button>
                                      </fieldset>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="right-content">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="content">
                                            <div class="section-heading">
                                                <span>More About Us</span>
                                                <h2>Venue Company</h2>
                                            </div>
                                            <p>Etiam viverra nibh at lorem hendrerit porta non nec ligula. Donec hendrerit porttitor pretium. Suspendisse fermentum nec risus eu bibendum.</p>
                                            <ul>
                                                <li><span>Phone:</span><a href="#">010-050-0550</a></li>
                                                <li><span>Email:</span><a href="#">hi@company.co</a></li>
                                                <li><span>Address:</span><a href="#">company.co</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
            </div>
        </div>
    </section>
    ---->
            <!------------------------------Fin seccion 8--------------------------------------------------->

            <!------------------------------seccion 9--------------------------------------------------->
            <footer>
                <div class="container" id="contacto">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="about-veno">
                                <div class="logo">
                                    <img src="Configuracion/images/vet31.png" alt="Venue Logo">
                                </div>
                                <p>nos preocupamos por el bienestar animal pero sobre todo por la comodidad y seguridad
                                    de sus dueños. Contamos con servicios en la comodidad de su hogar. .</p>
                                <ul class="social-icons">
                                    <li>
                                        <a href="https://www.facebook.com/VetDoctorMty"><i
                                                class="fa fa-facebook"></i></a>
                                        <a href="#"><i class="fa fa-twitter"></i></a>
                                        <a href="#"><i class="fa fa-linkedin"></i></a>
                                        <a href="#"><i class="fa fa-rss"></i></a>
                                        <a href="#"><i class="fa fa-dribbble"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="useful-links">
                                <div class="footer-heading">
                                    <h4>Otros servicios que se ofrece</h4>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-stop"></i>Consulta</a></li>
                                            <li><a href="#"><i class="fa fa-stop"></i>Desperacitacion</a></li>
                                            <li><a href="#"><i class="fa fa-stop"></i>Ultrasonido</a></li>
                                            <li><a href="#"><i class="fa fa-stop"></i>Radiografias</a></li>
                                            <li><a href="#"><i class="fa fa-stop"></i>Analisis Sanguineos</a></li>
                                            <li><a href="#"><i class="fa fa-stop"></i>Limpieza dental</a></li>
                                        </ul>
                                    </div>

                                    <div class="col-md-6">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-stop"></i>Esterilizacion</a></li>
                                            <li><a href="#"><i class="fa fa-stop"></i>Cremacion de mascota</a></li>
                                            <li><a href="#"><i class="fa fa-stop"></i>Adiestramiento Canino</a></li>
                                            <li><a href="#"><i class="fa fa-stop"></i>Fumigacion</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="contact-info">
                                <div class="footer-heading">
                                    <h4>Contactanos</h4>
                                </div>
                                <p>Tenemos servicio a domicilio.</p>
                                <ul>
                                    <li><span>Telefono:</span><a href="#">81 1040 3015</a></li>
                                    <li><span>Correo:</span><a href="#">VetDoctorMty@gmail.com</a></li>
                                    <li><span>Direccion:</span><a href="#">De la danza 1251 privadas de santa catarina,
                                            Santa Catarina</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>


            <!------------------------------Fin seccion 9--------------------------------------------------->
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js" type="text/javascript">
            </script>
            <script>
            window.jQuery || document.write('<script src="Configuracion/js/vendor/jquery-1.11.2.min.js"><\/script>')
            </script>

            <script src="Configuracion/js/vendor/bootstrap.min.js"></script>

            <script src="Configuracion/js/datepicker.js"></script>
            <script src="Configuracion/js/plugins.js"></script>
            <script src="Configuracion/js/main.js"></script>
            <script>
            .carousel - inner > .item > img {
                object - fit: scale - down;
                height: 30 vh;
                width: 80 % ;
            }
            </script>
</body>

</html>