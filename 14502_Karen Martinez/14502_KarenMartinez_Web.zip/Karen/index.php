<?php
//redireccionamiento a controlador para validación de sesiones

header("Location: controlador/val_inicio.php");
?>