<?php
$usuario = $_POST['usuario'];
$pass = $_POST['pass'];

include("../Modelo/operacion.php");
$objeto = new funciones();
$resultado = $objeto -> login($usuario, $pass);
if(empty($resultado)){
    exit(json_encode(
        ["status" => "2"]
    ));
}else{
    exit(json_encode(
        ["status" => "1", 
        "url" => "inicio"]
    ));
}
?>
