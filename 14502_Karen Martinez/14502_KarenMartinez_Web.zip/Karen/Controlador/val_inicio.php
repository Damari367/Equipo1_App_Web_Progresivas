<?php
session_start();
if(empty($_SESSION['registro'])){
    header("Location: ../registro");
} else{
    header("Location: ../inicio");
}
?>