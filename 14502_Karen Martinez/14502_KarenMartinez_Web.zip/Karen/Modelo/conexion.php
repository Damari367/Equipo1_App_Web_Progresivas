<?php
class conexion{

    public function con(){
        $link = mysqli_connect("localhost", "", "", "karenmartinez");
        $link -> set_charset("UTF8");
        return $link;

    }

}
?>