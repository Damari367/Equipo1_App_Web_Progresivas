<?php
    include("conexion.php");
    class funciones{
        private $db;
        private $lista;

        public function __construct(){
            $this->db = conexion::con();
            $this->arraydb = array();
        }

        public function registro_usuario($nombre, $correo, $usuario, $pass){
            $resultado = $this->db->query("
            INSERT INTO usuarios
            (nombre,
            correo,
            usuario,
            pass)
            VALUES
            ('$nombre','$correo','$usuario','$pass')");
            
        }

        public function login($usuario, $pass){
            $resultado = $this->db->query("SELECT * FROM usuarios WHERE usuario='$usuario' AND pass='$pass'");
            while ($fila = $resultado -> fetch_assoc()){
                $this->lista[] = $fila;
            }
            return $this->lista;
        }
        
    }
    
?>