<?php
class conexion{
    public function connect_db(){
        $con = mysqli_connect("localhost","","","karenmartinez");
        $con -> set_charset("UTF8");
        return $con;
    }
}
?>