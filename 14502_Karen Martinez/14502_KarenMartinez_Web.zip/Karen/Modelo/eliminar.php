<?php

    include("conexion.php");

    class eliminar{

        private $db;
        private $lista;

        public function __construct(){
            $this->db = conexion::con();
            $this->arraydb = array();
        }

        public function eliminar_producto($id){
            $resultado = $this->db->query("DELETE FROM productos WHERE id='$id'");
        }
        
    }
    
?>