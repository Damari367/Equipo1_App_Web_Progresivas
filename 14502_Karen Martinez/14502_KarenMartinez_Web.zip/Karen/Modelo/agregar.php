<?php

    include("conexion.php");

    class agregar{

        private $db;
        private $lista;

        public function __construct(){
            $this->db = conexion::con();
            $this->arraydb = array();
        }

        public function agregar_producto($name,$price){
            $resultado = $this->db->query("INSERT INTO productos (name,description , price) VALUES ('$name','DIMENSION: Airline approved, 17”L x 12”W x 12”H perfect for small pets up to 17 lbs, fits comfortably under seat. Don’t select carrier based on weight only. Choose carrier based on pet’s measurements first and stay within maximum weight limit allowing enough space for your pet.', '$price') ");
        }
        
    }
    
?>